MAPA — Batalha da Grã-Bretanha (Mapbox)

Arquivos deste pacote
---------------------
• batalha_gra-bretanha_token_prompt.html  → versão que pede o token na própria página
• batalha_gra-bretanha.html               → versão para editar o token no código
• batalha_da_gra-bretanha.geojson         → dados em GeoJSON (pontos do mapa)

Como visualizar (modo rápido — sem editar código)
-------------------------------------------------
1) Acesse mapbox.com, faça login e copie seu Access Token público (começa com “pk.”).
2) Abra o arquivo “batalha_gra-bretanha_token_prompt.html” (duplo clique).
3) Cole o token no campo do topo e clique em “Carregar mapa”.
4) Clique nos marcadores para ver os textos e links.
5) Para entregar: anexe este arquivo HTML (ou o ZIP), conforme orientação da disciplina.

Como visualizar (token embutido no HTML)
----------------------------------------
1) Abra “batalha_gra-bretanha.html” em um editor de texto.
2) Procure pela string COLE_SEU_TOKEN_AQUI e substitua pelo seu token (pk...).
3) Salve o arquivo e abra no navegador para testar.
4) Para entregar: envie esse HTML com o token já colocado.

Observações
-----------
• O token precisa ser público (prefixo “pk.”). Tokens “sk.” são secretos e não funcionam no browser.
• É necessário estar online para o mapa carregar (tiles e bibliotecas são baixados da internet).
• Se o mapa não aparecer, abra o Console do navegador (F12) e verifique mensagens como “Invalid access token”.
• O arquivo “batalha_da_gra-bretanha.geojson” contém os pontos e pode ser editado para incluir mais locais.
  Se preferir, dá para carregar esse GeoJSON no Mapbox Studio e publicar um link de visualização.

Entrega sugerida
----------------
• Enviar apenas o HTML “batalha_gra-bretanha_token_prompt.html” (sem editar código), ou
• Enviar o HTML “batalha_gra-bretanha.html” com o token já embutido, ou
• Enviar o pacote ZIP com todos os arquivos.
